# Authentication: setup and Postman walkthrough

Import `Delivery_App_Backend_Auth.postman_collection.json` into Postman. Requests include example JSON bodies, saved illustrative success/error responses, and scripts that capture OTP challenges and JWTs. Expand a request's examples to see response shapes. Example OTPs, IDs, dates and tokens are placeholders.

## 1. Environment and server setup

The existing `.env` passes the application's environment schema. Checked settings: `NODE_ENV=development`, `PORT=4000`, `OTP_EXPIRES_IN_MINUTES=5`, `JWT_EXPIRES_IN=7d`, `JWT_REMEMBER_ME_EXPIRES_IN=30d`. Database URL and JWT secret are configured; their values are intentionally excluded from this collection. `PUBLIC_API_BASE_URL` is empty; use the local URL below. Local API readiness was unavailable during this check, so database connectivity and live authentication have not been verified.

From the repository root:

```powershell
npm ci
# Keep your existing .env. Only copy .env.example if .env does not exist.
# Ensure PostgreSQL matches DATABASE_URL before applying migrations.
npm run db:generate
npm run db:deploy
npm run dev
```

If using the repository's local PostgreSQL container, start it with `docker compose up -d postgres` and ensure `.env` points to that database. Migrations change the configured database; check the target first.

## 2. Configure Postman

1. Import the collection JSON.
2. Open collection Variables. The production `baseUrl` is `http://40.81.244.167:3012/api/v1` (no trailing slash). For local testing, change it to `http://localhost:4000/api/v1`.
3. Set `fullName`, `countryCode`, `mobileNumber`, `email`, and `password`. Included sample values are `Postman Test User`, `+91`, `9876543210`, `postman.user@example.com`, and `Password123`.
4. Leave `challengeId`, `otp`, and `accessToken` empty. Scripts fill these automatically. Avoid variables with these same names in environment/global scopes, because they can override collection values.
5. Send Health → Liveness, then Readiness (API + Database). Expect HTTP 200 and `database: connected` for readiness.

## 3. Register and verify

Send **1. Register** (`POST /auth/register`):

```json
{
  "fullName": "Postman Test User",
  "countryCode": "+91",
  "mobileNumber": "9876543210",
  "email": "postman.user@example.com",
  "password": "Password123",
  "confirmPassword": "Password123",
  "acceptedTerms": true
}
```

Expect 201 with `data.challengeId`, `data.otp`, and `data.expiresAt`. This does not return a login token. Send **2. Verify OTP** (`POST /auth/verify-otp`):

```json
{ "challengeId": "{{challengeId}}", "otp": "{{otp}}" }
```

Expect 200 with `data.user`, `data.accessToken`, `data.tokenType: Bearer`, and `data.expiresIn: 7d`. The script saves the token. Send **Get Current User** to verify it works.

Registration requires a 2–100 character full name, a 7–15 digit mobile number, a password of 8–72 characters containing uppercase, lowercase and a number, matching confirmation, and boolean `acceptedTerms: true`. Email is optional but must be valid if supplied. Duplicate phone/email returns 409; change both for a new test user. Registration no longer silently randomizes your chosen phone/email.

## 4. Password login

Send **Login with Password** (`POST /auth/login`):

```json
{ "identifier": "postman.user@example.com", "password": "Password123", "rememberMe": true }
```

Or send **Login with Password - Mobile Number**:

```json
{ "countryCode": "+91", "mobileNumber": "9876543210", "password": "Password123", "rememberMe": true }
```

Expect 200 with an access token immediately; no OTP step is required for password login. `rememberMe: true` selects 30 days; false or omitted selects 7 days. Wrong credentials return 401.

## 5. OTP login and resend

Send **Login with OTP** to the same `POST /auth/login` endpoint, omitting `password`:

```json
{ "countryCode": "+91", "mobileNumber": "9876543210", "rememberMe": true }
```

Expect 200 with an OTP challenge. An unknown number returns 404. Optionally send **Resend OTP** before verification:

```json
{ "challengeId": "{{challengeId}}" }
```

Resend replaces the challenge and OTP; the script saves both. Send **Verify Login OTP** next to get a token. Codes last five minutes and allow five incorrect attempts. Creating a new challenge invalidates earlier active challenges for this user. A consumed challenge cannot be resent or verified again; initiate OTP login again.

## 6. Authenticated requests and logout

**Get Current User**, **Update Current User**, and **Check Authentication** inherit `Authorization: Bearer {{accessToken}}`. `/auth/check` returns HTTP 200 for both states: inspect `data.isLoggedIn`. It reports true only for the USER role.

Send **Logout - Clear Local Token**. Its pre-request script empties collection `accessToken`, `challengeId`, and `otp`; it then calls `GET /auth/check` with no authentication and expects `isLoggedIn: false` and `user: null`.

There is no `/auth/logout` route or server-side token revocation. Client logout means deleting the saved token and stopping Authorization headers. A copied token still works until expiration. This request does not log out another device or clear the separate administrator token.

## 7. Application implementation sequence

1. Registration screen: collect the registration fields and POST `/auth/register`. Save the returned challenge ID and expiry; open the OTP screen.
2. OTP screen: submit the entered six-digit code with that challenge ID to `/auth/verify-otp`. On resend, replace the challenge ID with the new response value.
3. Password login screen: POST the email/mobile identifier and password to `/auth/login`. OTP login screen: POST country code and mobile number without a password, then follow step 2.
4. On successful password login or OTP verification, store the returned token using your platform's appropriate session storage and load `/auth/me` with the Bearer header. Do not use illustrative response tokens.
5. Handle validation errors on the form, 409 as an existing account, expired/used OTPs by restarting login, and protected-request 401 by returning to login. Respect 429 rate-limit responses.
6. Logout: remove the saved token and in-memory user state, stop attaching the Authorization header, and return to login. Server-enforced logout requires a separate revocation/session implementation.

## Current backend limitations

The controller returns `otp` and `developmentOtp` even when `NODE_ENV=production`; only the `developmentOnly` flag changes. SMS delivery is not implemented. Before using real phone verification, integrate OTP delivery and omit codes from production responses. Password login currently does not enforce `mobileVerifiedAt`, so registration verification is not a prerequisite for password login in this implementation.

For manual testing, follow the sections above. The user-auth folder also orders registration → verification → OTP login → resend → verification → password login → profile checks → logout. Re-running registration with the same account returns 409. Administrator requests are separate and require a configured administrator password; they are not needed for user testing.
